<?php

namespace modules\adhoc;

/**
 * adhoc module definition class
 */
class Adhoc extends \yii\base\Module
{
    /**
     * @inheritdoc
     */
    public $controllerNamespace = 'modules\adhoc\controllers';

    /**
     * @inheritdoc
     */
    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
